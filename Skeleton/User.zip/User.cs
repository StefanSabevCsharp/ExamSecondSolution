using System.Collections.Generic;

namespace BitcoinWalletManagementSystem
{
    public class User
    {
        public User()
        {
            this.Wallets = new HashSet<Wallet>();
            this.Transactions = new HashSet<Transaction>();
        }
        public string Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }
        public HashSet<Wallet> Wallets { get; set; }
        public HashSet<Transaction> Transactions { get; set; }
    }
}