using System;
using System.Collections.Generic;
using System.Linq;

namespace BitcoinWalletManagementSystem
{
    public class BitcoinWalletManager : IBitcoinWalletManager
    {
        private Dictionary<string, User> users = new Dictionary<string, User>();
        private Dictionary<string, Wallet> wallets = new Dictionary<string, Wallet>();
        
        private Dictionary<User, List<Transaction>> transactionsByUserId = new Dictionary<User, List<Transaction>>();

        public void CreateUser(User user)
        {
            if (!this.users.ContainsKey(user.Id))
            {

                this.users.Add(user.Id, user);
            }
        }

        public void CreateWallet(Wallet wallet)
        {

            if(!this.wallets.ContainsKey(wallet.Id))
            {
                this.wallets.Add(wallet.Id, wallet);
            }

            if(!this.users.ContainsKey(wallet.UserId))
            {
                User currentUser = new User() { Id = wallet.UserId };
                currentUser.Wallets.Add(wallet);
                wallet.User = currentUser;
                
            }
            else
            {
                this.users[wallet.UserId].Wallets.Add(wallet);
            }
        }

        public bool ContainsUser(User user)
        {
            return this.users.ContainsKey(user.Id);
        }

        public bool ContainsWallet(Wallet wallet)
        {
            return this.wallets.ContainsKey(wallet.Id);
        }

        public IEnumerable<Wallet> GetWalletsByUser(string userId)
        {
            HashSet<Wallet> userWallets = new HashSet<Wallet>();
            userWallets = this.users[userId].Wallets;
            return userWallets;
        }

        public void PerformTransaction(Transaction transaction)
        {

            string firstWalletID = transaction.SenderWalletId;
            string secondWalletID = transaction.ReceiverWalletId;
            Wallet firstWallet = this.wallets[firstWalletID];
            Wallet receiverWallet = this.wallets[secondWalletID];

            User firstUser = this.users[firstWallet.UserId];
            User secondUser = this.users[receiverWallet.UserId];
            if (firstUser == null || secondUser == null)
            {
                throw new ArgumentException();
            }
            if (firstWallet.Balance < transaction.Amount
                || !firstUser.Wallets.Contains(firstWallet)
                || !secondUser.Wallets.Contains(receiverWallet))
            {
                throw new ArgumentException();
            }
            else
            {

                firstWallet.Balance -= transaction.Amount;
                receiverWallet.Balance += transaction.Amount;
                
            }
            if (!transactionsByUserId.ContainsKey(firstUser))
            {
                transactionsByUserId[firstUser] = new List<Transaction>();
            }

            if (!transactionsByUserId.ContainsKey(secondUser))
            {
                transactionsByUserId[secondUser] = new List<Transaction>();
            }

            transactionsByUserId[firstUser].Add(transaction);
            transactionsByUserId[secondUser].Add(transaction);

        }

        public IEnumerable<Transaction> GetTransactionsByUser(string userId)
        {
          return this.transactionsByUserId[this.users[userId]];
            //return this.users[userId].Transactions;
        }

        public IEnumerable<Wallet> GetWalletsSortedByBalanceDescending()
        {
            return this.wallets.Values.OrderByDescending(w => w.Balance);
        }

        public IEnumerable<User> GetUsersSortedByBalanceDescending()
        {

            return this.users.Values.OrderByDescending(u => u.Wallets.Sum(w => w.Balance));
        }

        public IEnumerable<User> GetUsersByTransactionCount()
        {
            HashSet<User> userTransactions = new HashSet<User>();
            userTransactions = this.users.Values.OrderByDescending(u => u.Transactions.Count).ToHashSet();
            return userTransactions;
        }
    }
}